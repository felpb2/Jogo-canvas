let canvas = document.getElementById('canvas');
let ctx = canvas.getContext('2d');

let animacaoId; //usado para fazer a ultima linha
let pontuacao = 0;
// velocidade crescente 
let velocidade = 1;

// lista que usei para o código
let linhas = [];

// usei uma funcao para repetir as linhas 
function criarLinha(x, y, altura, largura, cor) {
    return {
        x: x,
        y: y,
        altura: altura,
        largura: largura,
        cor: cor,
        desenha: function () {
            ctx.beginPath();
            ctx.fillStyle = this.cor;
            ctx.fillRect(this.x, this.y, this.largura, this.altura);
            ctx.closePath();
        },
        atualiza: function () {
            this.y = this.y - velocidade;
            if (this.y < -this.largura) {
                this.y = 1000;
            } else {
                this.desenha();
            }
        }
    };
}

// linhas da direita
linhas.push(criarLinha(250, 1000, 50, 20, "yellow"));
linhas.push(criarLinha(250, 800, 50, 20, "yellow"));
linhas.push(criarLinha(250, 600, 50, 20, "yellow"));
linhas.push(criarLinha(250, 400, 50, 20, "yellow"));
linhas.push(criarLinha(250, 200, 50, 20, "yellow"));

// linhas da esquerda
linhas.push(criarLinha(500, 1000, 50, 20, "yellow"));
linhas.push(criarLinha(500, 800, 50, 20, "yellow"));
linhas.push(criarLinha(500, 600, 50, 20, "yellow"));
linhas.push(criarLinha(500, 400, 50, 20, "yellow"));
linhas.push(criarLinha(500, 200, 50, 20, "yellow"));

// objeto onibus
let onibus = {
    x: 270,
    y: 10,
    altura: 200,
    largura: 160,
    img: new Image(),
    desenha: function () {
        this.img.src = 'images/onibus0.png';
        ctx.beginPath();
        ctx.drawImage(this.img, this.x, this.y, this.largura, this.altura);
        ctx.closePath();
    }
}

// objeto carros
let carros = {
    // posicao aleatoria do carro
    x: Math.floor(Math.random() * 650) + 1,
    y: 1000,
    altura: 180,
    largura: 150,
    img: new Image(),
    desenha2: function () {
        this.img.src = 'carro2.png';
        ctx.beginPath();
        ctx.drawImage(this.img, this.x, this.y, this.largura, this.altura);
        ctx.closePath();
    },
    // animacao carro
    atualiza: function () {
        carros.y = carros.y - velocidade;
        if (carros.y < 0) {
            carros.y = 1000;
            carros.x = Math.floor(Math.random() * 650) + 1;
            velocidade += 0.5;
        }
    }
}

function colisao() {
    // Calcula as coordenadas dos limites do ônibus
    let onibusEsquerda = onibus.x;
    let onibusDireita = onibus.x + onibus.largura;
    let onibusTopo = onibus.y;
    let onibusBase = onibus.y + onibus.altura;

    // Calcula as coordenadas dos limites dos carros
    let carrosEsquerda = carros.x + 75;
    let carrosDireita = carros.x + carros.largura - 75;
    let carrosTopo = carros.y + 10;
    let carrosBase = carros.y + carros.altura;

    // Verifica se houve colisão
    if (
        carrosBase >= onibusTopo && // Carro está abaixo do topo do ônibus
        carrosTopo <= onibusBase && // Carro está acima da base do ônibus
        carrosDireita >= onibusEsquerda && // Carro está à direita da borda esquerda do ônibus
        carrosEsquerda <= onibusDireita // Carro está à esquerda da borda direita do ônibus
    ) {
        cancelAnimationFrame(animacao);
    } else {
        // Se não houver colisão, continue a animação
        requestAnimationFrame(animacao);
    }
}

// animacao
function animacao() {
    ctx.clearRect(0, 0, 750, 1000);
    linhas.forEach(function (linha) {
        linha.atualiza();
    });
    onibus.desenha();
    // pontuacao se passar dos carros
    carros.atualiza();
    carros.atualiza();
    carros.desenha2();
    if (carros.y + carros.altura == onibus.y - onibus.altura) {
        pontuacao += 10;
        document.getElementById("pont").innerHTML = pontuacao;
        console.log(pontuacao);
    }
    colisao();
}

// movimentação por setas
document.addEventListener('keydown', function (evento) {
    let tecla = evento.key;
    console.log(tecla);
    if (tecla == 'ArrowUp' && onibus.y > 0) { onibus.y = onibus.y - 50; }
    if (tecla == 'ArrowDown' && onibus.y < 800) { onibus.y = onibus.y + 50; }
    if (tecla == 'ArrowLeft' && onibus.x > -20) { onibus.x = onibus.x - 50; }
    if (tecla == 'ArrowRight' && onibus.x < 610) { onibus.x = onibus.x + 50; }
});

repetido = 0
document.getElementById('startButton').addEventListener('click', function () {
    velocidade = 0.5;
    pontuacao = 0;
    carros.y = 1000;
    onibus.y = 0;
    carros.x = Math.floor(Math.random() * 650) + 1;
    repetido +=1
});

if (repetido == 0){
    animacaoId = requestAnimationFrame(animacao);
}else{
    window.alert("Pressione o botão restart para jogar de novo !!!")
}
    
document.getElementById('restartButton').addEventListener('click', function () {
    velocidade = 0.5;
    pontuacao = 0;
    carros.y = 1000;
    onibus.y = 0;
    carros.x = Math.floor(Math.random() * 650) + 1;
    animacaoId = requestAnimationFrame(animacao);
});
